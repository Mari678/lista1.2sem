﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areaQuadrado
{
    internal class Area
    {
        private double n1;
        private double resultado;
        public void setN1(double n)
        {
            n1 = n;
        }

        public double getN1()
        {
            return n1;
        }

        public double setResultado()
        {
            return resultado;
        }

        public void multiplicar()
        {
            resultado = n1 * n1;
        }
    }
}
