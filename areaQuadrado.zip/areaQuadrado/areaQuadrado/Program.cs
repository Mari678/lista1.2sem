﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areaQuadrado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Area mult1;
            mult1 = new Area();

            Console.WriteLine("Insira o valor da aresta: ");
            mult1.setN1(double.Parse(Console.ReadLine()));

            mult1.multiplicar();

            Console.WriteLine("O quadrado com {0} de aresta possui {1} de área", mult1.getN1(), mult1.setResultado());
        }
    }
}
