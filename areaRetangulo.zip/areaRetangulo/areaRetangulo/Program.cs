﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areaRetangulo
{
    class Program
    {
        static void Main(string[] args)
        {
            Area area1;
            area1 = new Area();

            Console.WriteLine("Digite o valor da base: ");
            area1.setN1(double.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o valor da altura: ");
            area1.setN2(double.Parse(Console.ReadLine()));

            area1.multiplicar();

            Console.WriteLine("O retângulo de base {0} e altura {1} possui área {2}", area1.getN1(), area1.getN2(), area1.getResultado());
        }
    }

    class Area
    {
        private double n1;
        private double n2;
        private double resultado;

        public void setN1(double n)
        {
            n1 = n;
        }
        public void setN2(double n)
        {
            n2 = n;
        }
        public double getN1() 
        {
            return n1;
        }
        public double getN2 ()
        {
            return n2;
        }
        public double getResultado ()
        {
            return resultado;
        }
        public void multiplicar ()
        {
            resultado = n1 * n2;
        }
    }
}
